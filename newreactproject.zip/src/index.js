import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import Test from "./components/Test";
import Accortion from './components/accordion/Accortion';
import Employees from "./components/employees/Employe";
import Notepad from './components/Notepad/Notepad';
import ComA from "./components/Content_API/ComA";

const container = document.getElementById('root');
const root = ReactDOM.createRoot(container);
root.render(<Notepad />);