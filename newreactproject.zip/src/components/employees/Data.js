const EmployeData = [
    {
        no: 1,
        name : "Ali",
        salery: "30000"
    },
    {
        no: 2,
        name : "Babar",
        salery: "35000"
    },
    {
        no: 3,
        name : "Junaid",
        salery: "45000"
    }
]

export default EmployeData;