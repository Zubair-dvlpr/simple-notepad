 const questions = [
    {
        id: 1,
        question : "Who are you",
        answer: "My name is zubair."
    },
    {
        id: 2,
        question : "How are you..?",
        answer: "I Am Fine And About You...!"
    }
    ,
    {
        id: 3,
        question : "How are you..?",
        answer: "I Am Fine And About You...!"
    }
    ,
    {
        id: 4,
        question : "How are you..?",
        answer: "I Am Fine And About You...!"
    }
    ,
    {
        id: 5,
        question : "How are you..?",
        answer: "I Am Fine And About You...!"
    }
]

export default questions;