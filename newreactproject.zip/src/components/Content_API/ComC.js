import React from "react";
import ComD from "./ComD";

const ComC = ()=> {
    return(
        <React.Fragment>
            <ComD />
        </React.Fragment>
    )
}

export default ComC;