import React from "react";
import ComC from "./ComC";

const ComB = ()=> {
    return(
        <React.Fragment>
            <ComC />
        </React.Fragment>
    )
}

export default ComB;